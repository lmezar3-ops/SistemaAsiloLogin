using Microsoft.AspNetCore.Mvc;

namespace MicroservicioMedicamentos.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MedicamentosController : ControllerBase
    {
        [HttpGet("vencer")]
        public IActionResult GetMedicamentosPorVencer()
        {
            var medicamentos = new[]
            {
                new
                {
                    id = 1,
                    nombre = "Paracetamol",
                    fechaVencimiento = "2026-09-01"
                },
                new
                {
                    id = 2,
                    nombre = "Amoxicilina",
                    fechaVencimiento = "2026-09-15"
                },
                new
                {
                    id = 3,
                    nombre = "Ibuprofeno",
                    fechaVencimiento = "2026-10-05"
                }
            };

            return Ok(medicamentos);
        }
    }
}

